package com.cts.entity;
import java.util.*;

import javax.persistence.*;


@Entity
//@XmlRootElement
public class EventMaster {

	@Id
	private int eventId;

	public int getEventId() {
		return eventId;
	}
	
	@ManyToMany(
	        cascade = {CascadeType.PERSIST, CascadeType.MERGE},
	        mappedBy = "events",
	        targetEntity = CustomerMaster.class
	    )
	    private Set<CustomerMaster> customers=new HashSet<CustomerMaster>();

	public Set<CustomerMaster> getCustomers() {
		return customers;
	}

	public void setCustomers(Set<CustomerMaster> customers) {
		this.customers = customers;
	}

	public void setEventId(int eventId) {
		this.eventId = eventId;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getEventDate() {
		return eventDate;
	}

	public void setEvent_date(String eventDate) {
		this.eventDate = eventDate;
	}

	public int getTicketsAvailable() {
		return ticketsAvailable;
	}

	public void setTicketsAvailable(int ticketsAvailable) {
		this.ticketsAvailable = ticketsAvailable;
	}

	public int getLocationId() {
		return locationId;
	}

	public void setLocationId(int locationId) {
		this.locationId = locationId;
	}

	@Column
	private String eventName;
	@Column
	private String eventDate;
	@Column
	private int ticketsAvailable;
	@Column
	private int locationId;
	
}
