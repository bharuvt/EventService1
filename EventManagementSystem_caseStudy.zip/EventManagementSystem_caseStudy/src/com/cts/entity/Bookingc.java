package com.cts.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class Bookingc implements Serializable {
	
	private static final long serialVersionUID = 1L;
	@Column
	private int eventId;
	@Column
	private int custId;

	public int getEventId() {
		return eventId;
	}

	public void setEvent_id(int eventId) {
		this.eventId = eventId;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

}
