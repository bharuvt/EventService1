package com.cts.entity;

import java.util.*;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.cts.util.HibernateUtil;




public class EventManager {

	public void insertCustomers(int custId,String name,String custAddress){
		SessionFactory sf=null;
	  Session session=null;
	  Transaction tr=null;
	  try{
		  sf=HibernateUtil.getSessionFactory();
		  session=sf.openSession();
		   tr=session.beginTransaction();
		 
		   CustomerMaster c=new CustomerMaster();
		   c.setCustId(custId);
		   c.setCustName(name);
		   c.setCustAddress(custAddress);
		   session.save(c);
			  tr.commit();
		 }
	 
	 catch(Exception e){
		 System.out.println(e +"  Error with Customer insert block");
		 tr.rollback();
		 session.close();
	 }
	}
	 public void insertEvents(int id,String name){
			SessionFactory sf=null;
		  Session session=null;
		  Transaction tr=null;
		  try{
			  sf=HibernateUtil.getSessionFactory();
			  session=sf.openSession();
			   tr=session.beginTransaction();
			   EventMaster s=new EventMaster();
			   s.setEventId(id);
			   s.setEventName(name);
				session.save(s);
			   tr.commit();
			 }
		 
		 catch(Exception e){
			 System.out.println(e+"  Error with Event insert block");
			 tr.rollback();
			 session.close();
		 }
	 }
	 public void addCustomers_to_Event(int lowerCustId,int upperCuatId,int eventCode){
		 // particular event 
		 
		 //this is not mandatory - to check for many-many
		 
		 SessionFactory sf=null;
		  Session session=null;
		  Transaction tr=null;
		  try{
			  sf=HibernateUtil.getSessionFactory();
			  session=sf.openSession();
			   tr=session.beginTransaction();
			   EventMaster c=(EventMaster)session.load(EventMaster.class,new Integer(eventCode));
			   Set s=c.getCustomers();
			   List l=session.createQuery("from CustomerMaster where cust_id between "+lowerCustId+" and "+upperCuatId).list();
			   for(int i=0;i<l.size();i++){
				   CustomerMaster customer=(CustomerMaster)l.get(i);
				   System.out.println("Customer: "+customer.getCustName());
			    s.add(customer);
			   }
			   c.setCustomers(s);
			   session.save(c);
			   tr.commit();
		  	}
		  catch(Exception e){
				 System.out.println(e+"  Error with Customer_MAster_event add block");
				 tr.rollback();
				 session.close();
			 }
	 }
	 public void addEvents_to_Customer(int lowerCCode,int upperCCode,int eventId){
		 // this is not mandatory - to check for many-many
		 
		 SessionFactory sf=null;
		  Session session=null;
		  Transaction tr=null;
		try {
			sf = HibernateUtil.getSessionFactory();
			session = sf.openSession();
			tr = session.beginTransaction();
			CustomerMaster s = (CustomerMaster) session.load(CustomerMaster.class,
					new Integer(eventId));
			Set st = s.getEvents();
			List l = session.createQuery(
					"from EventMaster where event_id between " + lowerCCode
							+ " and " + upperCCode).list();
			for (int i = 0; i < l.size(); i++) {
				EventMaster eve = (EventMaster) l.get(i);
				System.out.println("Event name : "+eve.getEventName());
				st.add(eve);
			}
			s.setEvents(st);
			session.save(s);
			tr.commit();
		}
		  catch(Exception e){
				 System.out.println(e+"  Error with Event_customer add block");
				 tr.rollback();
				 session.close();
			 }
	 }
}