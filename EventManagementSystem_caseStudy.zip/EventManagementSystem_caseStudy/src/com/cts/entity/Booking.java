package com.cts.entity;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="Booking_V")
public class Booking {

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "event_id", column = @Column(name = "event_id")),
			@AttributeOverride(name = "cust_id", column = @Column(name = "cust_id")) })
	private Bookingc bookingc;	

	public Bookingc getBookingc() {
		return bookingc;
	}

	public void setBookingc(Bookingc bookingc) {
		this.bookingc = bookingc;
	}

	public int getTicketsBooked() {
		return ticketsBooked;
	}

	public void setTicketsBooked(int ticketsBooked) {
		this.ticketsBooked = ticketsBooked;
	}

	public float getAmount() {
		return amount;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}

	@Column
	private int ticketsBooked;
	@Column
	private float amount;


}
